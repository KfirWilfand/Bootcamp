var counter = 0;

$(document).ready(function() {
  $(":button").click(function(e) {
    $("span").text(counter);
    counter++;
  });
});
